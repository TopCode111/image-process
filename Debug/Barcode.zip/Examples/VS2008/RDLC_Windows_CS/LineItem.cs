namespace RDLC_Windows_CS
{
    public class LineItem
    {
        public string Product { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
    };
}